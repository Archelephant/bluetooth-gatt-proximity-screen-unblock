package com.example.android.bluetoothlegatt;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;

/**
 * Created by lurye on 09/12/16.
 */

//A special activity to bypass the screen guard in Android 6 and above

public class KeyGuardDismissActivity extends Activity {
    private ScreenOnReceiver receiver;
    public String TAG = "KeyGuardDismissActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Log.d(TAG, "Keyguard dismisser started...");
        //version checker?
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP){
            startActivity(new Intent(this, DeviceControlActivity.class));
            finish();
            return;
        }
        this.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        receiver = new ScreenOnReceiver();
        registerReceiver(receiver, receiver.getFilter());
    }

    private void dismisingKeyguard(){
        Log.d(TAG, "Dismissing keyguard...");
        startActivity(new Intent(this, DeviceControlActivity.class));
        if (receiver != null){
            unregisterReceiver(receiver);
        }
        finish();
    }

    private class ScreenOnReceiver extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent){
            Log.d(TAG, "Screen on!");
            dismisingKeyguard();
        }


        public IntentFilter getFilter(){
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_ON);
            return filter;
        }
    }
}
